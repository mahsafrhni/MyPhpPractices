<?php

class Giraffe extends Vegetarian
{
    public function walk()
    {
        return "Walking...";
    }
}