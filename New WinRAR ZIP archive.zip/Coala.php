<?php

class Coala extends Vegetarian
{
    public function findLeaves()
    {
        return "Leaves found successfully!";
    }
}