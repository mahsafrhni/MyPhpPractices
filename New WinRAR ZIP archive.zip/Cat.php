<?php

class Cat extends Carnivore
{
    public function Meow()
    {
        return "meow!";
    }
    public function Run()
    {
        return "Run!";
    }
}